#include <iostream>

/** Calculates the sum of all integers from 0 to max inclusive.
 * @param max The max value to add
 * @return The sum of all values from 0 to max
 */
int* calc_sum (int max) {
    int* sum = new int(0);

    for (int i = 0; i <= max; i++) {
        *sum += i;
    }

    return sum;
}

int main() {
    int* a = calc_sum(15);

    std::cout << *a << std::endl;

    delete a;
}