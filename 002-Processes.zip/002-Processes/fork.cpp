#include <unistd.h>
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>

int main() {

    pid_t fork_val = fork(); // Splits our process into two 

    if (fork_val == 0) {
        execlp("./child", "./child", NULL);
        // Why didn't this line execute?
        // Exec only returns if the process fails
        std::cout << "Failed to exec()" << std::endl;
    }


    else {
        int exit_val = 0;
        // Race condition.
        std::cout << "my child PID is " << fork_val << std::endl;
        std::cout << "my exit code was " << exit_val << std::endl;
        waitpid(fork_val, &exit_val, 0);

    }
}